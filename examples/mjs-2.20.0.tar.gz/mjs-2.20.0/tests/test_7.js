let x = 1;
let y = x++;
if (x > 0) x++;
x === 3 && y === 1 && !'' === true && !!'' === false;
