
function err1f2() {
  return bar;
}

function err1f1() {
  return err1f2();
}
