
function err2f1() {
  return err2f2();
}

function err2f2() {
  return bar;
}
