typeof 1 === 'number' && typeof('foo') === 'string' && typeof '' === 'string' &&
    typeof(1 === 2) === 'boolean' && typeof(true) === 'boolean' &&
    typeof false === 'boolean' && typeof[] === 'array' &&
    typeof({}) === 'object' && typeof print === 'foreign_ptr' &&
    typeof(function() {}) === 'function' && typeof null === 'null' &&
    typeof undefined === 'undefined';
